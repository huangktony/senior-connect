import "expo-router/entry";
